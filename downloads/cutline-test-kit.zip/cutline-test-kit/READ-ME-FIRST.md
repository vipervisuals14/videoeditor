# Cutline test kit — Resolve test kit

A Travel vlog edit from Cutline, packaged to import on another machine.

## Import

1. Unzip this folder anywhere. Keep `timeline.otio` next to the `media/` folder.
2. Open DaVinci Resolve (Free is fine) and create or open a project.
3. **File → Import → Timeline**, choose `timeline.otio`.
4. If Resolve asks, point the media at this folder's `media/` directory.

## What to look at

- Tracks, top to bottom, should read: `V1 Program`, `V2 Transitions`, `V3 Captions`, `V4 Titles`, `V5 Collage`, `V6 Viewfinder`, `A1 Audio` (only the tracks this cut uses are present).
- The captions/overlays are alpha movies. They should composite with transparency, not as black boxes.
- Every clip should be trimmable, and the source timecodes in each clip's Properties should match the original footage.
- Scrubbing the cut should not leave a gap between clips on V1.

## Files

- `timeline.otio` — the edit
- `media/` — the exact files the timeline references (all copied, this kit is portable)

## If the import looks wrong, send back

- Resolve version, edition (Free/Studio), and OS
- A screenshot of the timeline page right after import
- Anything Resolve printed in the import dialog

Those three answer almost every import question.
