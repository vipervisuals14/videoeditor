# Cutline test kit

Cut with **Cutline** for DaVinci Resolve Free.

- Mode: Travel vlog
- Timeline: 20.3s at 30 fps · 1920×1080
- Clips: 6 · cuts: 5 · removed: 3.7s
- Captions: 12 cues (File · SRT · source timing)
- Transitions: 2

## Import into Resolve

1. Open your project in DaVinci Resolve (Free is fine).
2. Choose **File → Import → Timeline** (Shift+Command/Ctrl+I).
3. Select `timeline.otio` from this folder.
4. The cut lands on V1, transitions on V2, captions on V3, titles on V4, audio on A1. The opening collage on V5 and the viewfinder HUD on V6 sit above the cut.
5. Captions are also exported as `captions.srt` if you want Resolve's subtitle track.

Footage stays linked to its original location. Keep those drives mounted.

## Warnings

- None.

Generated files:
- `timeline.otio`
- `captions.srt`
- `preview.jpg`
